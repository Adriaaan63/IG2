#pragma once
const int TILE_WIDTH = 100;
const int TILE_HEIGHT = 100;