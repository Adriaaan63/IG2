#pragma once
const int TILE_WIDTH = 100;
const int TILE_HEIGHT = 100;
const int WIDTH_FLOOR = 300;
const int HEIGHT_FLOOR = 150;
const int PS_FIRE = 10;

