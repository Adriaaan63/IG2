//#pragma once
//#include "Bloque.h"
//class Muro : public Bloque
//{
//public:
//    Muro(Vector3 pos, SceneNode* node, SceneManager* sceneManager)
//        : Bloque(pos, node, sceneManager, "cube.mesh") {}
//    void init() override {}
//};
//
